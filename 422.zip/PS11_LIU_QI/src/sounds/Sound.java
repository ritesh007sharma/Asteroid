package sounds;

import java.io.BufferedInputStream;
import java.io.IOException;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class Sound
{
    private Clip fireClip;
    
    private Clip smallSaucerClip;
    
    private Clip BigSaucerClip;
    
    private Clip thrustClip;
    
    private Clip  bangShipClip;
    
    private Clip beat1Clip;
    
    private Clip beat2Clip;
    
    private Clip bangM;
    
    private Clip bangL;
    
    private Clip bangS;
    
    private Clip bangAlienShip;
    
    
    public Sound()
    {
        fireClip = createClip("/sounds/fire.wav");
        smallSaucerClip = createClip("/sounds/saucerSmall.wav");
        BigSaucerClip = createClip("/sounds/saucerBig.wav");
        thrustClip = createClip("/sounds/thrust.wav");
        bangShipClip = createClip("/sounds/bangShip.wav");
        beat1Clip = createClip("/sounds/beat1.wav");
        bangM = createClip("/sounds/bangMedium.wav");
        bangL = createClip("/sounds/bangLarge.wav");
        bangS = createClip("/sounds/bangSmall.wav");
        beat2Clip = createClip("/sounds/beat2.wav");
        bangAlienShip = createClip("/sounds/bangAlienShip.wav");
        
    }
    
    public Clip createClip (String soundFile)
    {
        // Opening the sound file this way will work no matter how the
        // project is exported. The only restriction is that the
        // sound files must be stored in a package.
        try (BufferedInputStream sound = new BufferedInputStream(getClass().getResourceAsStream(soundFile)))
        {
            // Create and return a Clip that will play a sound file. There are
            // various reasons that the creation attempt could fail. If it
            // fails, return null.
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(sound));
            return clip;
        }
        catch (LineUnavailableException e)
        {
            return null;
        }
        catch (IOException e)
        {
            return null;
        }
        catch (UnsupportedAudioFileException e)
        {
            return null;
        }
    }
    
}
