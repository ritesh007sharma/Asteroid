package asteroids.destroyers;

public interface AlienShipDestroyer
{

}
