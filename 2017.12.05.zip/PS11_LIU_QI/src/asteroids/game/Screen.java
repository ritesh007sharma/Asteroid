package asteroids.game;

import static asteroids.game.Screen.*;
import static asteroids.game.Constants.*;
import java.awt.*;
import java.awt.geom.Path2D;
import java.util.Iterator;
import javax.swing.*;

/**
 * The area of the display in which the game takes place.
 */
@SuppressWarnings("serial")
public class Screen extends JPanel
{
    /** Legend that is displayed across the screen */
    private String legend;

    /** Game controller */
    private Controller controller;
    
    private Display display;
    
    private JLabel scoresLabel;

    /**
     * Creates an empty screen
     */
    public Screen (Controller controller, Display display)
    {
        this.controller = controller;
        this.display = display;
        legend = "";
        setPreferredSize(new Dimension(SIZE, SIZE));
        setMinimumSize(new Dimension(SIZE, SIZE));
        setBackground(Color.black);
        setForeground(Color.white);
        setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 120));
        setFocusable(true);

//        /** Creates a JPanel to contain lives remaining, scores and level */
//        setLayout(new BorderLayout());
//        JPanel data = new JPanel();
//        data.setLayout(new BorderLayout());
//        data.setBackground(Color.black);
//        add(data, "North");
//
//        /** Creates a JPanel to contain the scores and lives remaining */
//        JPanel livesAndScores = new JPanel();
//        livesAndScores.setBackground(Color.black);
//        livesAndScores.setOpaque(true);
//        livesAndScores.setLayout(new BorderLayout());
//        data.add(livesAndScores, "West");
//
//        /** Creates a JLabel to contain the scores */
//        scoresLabel = new JLabel();
//        scoresLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 120));
//        scoresLabel.setForeground(Color.white);
//        livesAndScores.add(scoresLabel, "North");
//
//        /** Creates a JPanel to contain the lives remaining */
//        JPanel livesPanel = new JPanel();
//        livesPanel.setLayout(new GridLayout(1, 3));
//        for (int i = 0; i < 3; i++)
//        {
//            Lives live = new Lives(i);
//            livesPanel.add(live);
//        }
//        livesAndScores.add(livesPanel,"South");
//        refresh();

    }

    /**
     * Set the legend
     */
    public void setLegend (String legend)
    {
        this.legend = legend;
    }
    
//    public void setScores()
//    {
//        scoresLabel.setText(controller.getScores()+"");
//    }
    
//    public void refresh()
//    {   
//        Component[] shipShap = this.getComponents();
//        for(Component s : shipShap)
//        {
//            if(s instanceof Lives)
//            {   
//                Lives l = (Lives) s;
//                if(controller.getLives() == 2 && l.getIndex() == 2)
//                {
//                    l.setColor(Color.black);
//                }
//                else if(controller.getLives() == 1 && l.getIndex() == 1)
//                {
//                    l.setColor(Color.black);
//                }
//                else if( controller.getLives() == 0 && l.getIndex() == 0)
//                {
//                    l.setColor(Color.black);
//                }
//            }
//        }
//        this.setScores();
//        this.repaint();
//    }

    /**
     * Paint the participants onto this panel
     */
    @Override
    public void paintComponent (Graphics graphics)
    {
        // Use better resolution
        Graphics2D g = (Graphics2D) graphics;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        // Do the default painting
        super.paintComponent(g);

        // Draw each participant in its proper place
        Iterator<Participant> iter = controller.getParticipants();
        while (iter.hasNext())
        {
            iter.next().draw(g);
        }

        // Draw the legend across the middle of the panel
        int size = g.getFontMetrics().stringWidth(legend);
        g.drawString(legend, (SIZE - size) / 2, SIZE / 2);
    }
}

@SuppressWarnings("serial")
class Lives extends JLabel
{
    /** The location of the ship symbol */
    private int index;

    /** The color pf the ship symbol */
    private Color color;

    public Lives (int index)
    {
        this.index = index;
        this.color = Color.white;
    }

    public int getIndex ()
    {
        return this.index;
    }

    public void setColor (Color color)
    {
        this.color = color;
    }

    public void paintComponent (Graphics g)
    {
        ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(Color.black);
        g.fillRect(0, 0, getWidth(), getHeight());

        g.setColor(Color.white);
        g.drawLine(10, 0, 0, 20);
        g.drawLine(10, 0, 20, 20);
        g.drawLine(4, 24, 16, 24);
    }
}
