package asteroids.participants;

import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import javax.sound.sampled.Clip;
import asteroids.destroyers.*;
import asteroids.game.*;
import sounds.Sound;
import static asteroids.game.Constants.*;

public class AlienShip extends Participant implements ShipDestroyer
{
    /** The outline of the ship */
    private Shape outline;

    /** Game controller */
    private Controller controller;

    private double speed;

    private double direction;

    private Sound sound;

    private double size;
    
    private int count;

    /**
     * Constructs an alien ship at the specified coordinates that is pointed in the given direction.
     */
    public AlienShip (int x, int y, double speed, double direction, double size, Controller controller)
    {
        this.controller = controller;
        setPosition(x, y);
        this.size = size;
        this.speed = speed;
        this.direction = direction;
        sound = new Sound();
        this.killShip();
        this.count = 0;

        Path2D.Double poly = new Path2D.Double();
        poly.moveTo(-5, 0);
        poly.lineTo(-5, -7);
        poly.lineTo(5, -7);
        poly.lineTo(5, 0);
        poly.lineTo(-7, 0);
        poly.lineTo(-17, 14);
        poly.lineTo(-13, 21);
        poly.lineTo(13, 21);
        poly.lineTo(17, 14);
        poly.lineTo(7, 0);
        poly.lineTo(5, 0);
        poly.moveTo(17, 14);
        poly.lineTo(-17, 14);
        poly.closePath();
        outline = poly;

        poly.transform(AffineTransform.getScaleInstance(size, size));
        new ParticipantCountdownTimer(this, "appearing", 5000);
        new ParticipantCountdownTimer(this, "moving", 5000);
        new ParticipantCountdownTimer(this, "killing", 5000);
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(0, 0);
        transformPoint(point);
        return point.getX();

    }

    /**
     * Returns the y-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(0, 0);
        transformPoint(point);
        return point.getY();
    }

    @Override
    public void move ()
    {
        super.move();
            if (this.direction < 0 && this.getX() >= 0 && this.getX() < 4)
            {
                Participant.expire(this);

                appearAgain();
            }
            else if (this.direction >= 0 && this.getX() > SIZE - 4 && this.getX() <= SIZE)
            {
                Participant.expire(this);

                appearAgain();
            }
        
        
//        count++;
//        Clip BigSaucerClip = sound.createClip("/sounds/saucerBig.wav");
//        Clip smallSaucerClip = sound.createClip("/sounds/saucerSmall.wav");
//        if(count > 5000 && count <7500 )
//        {
//            if(this.size == ALIENSHIP_SCALE[0])
//            {
//                smallSaucerClip.start();
//            }
//            else
//            {
//                BigSaucerClip.start();
//            }
//        }
        
        

    }

    public void appearAgain ()
    {
        int d = RANDOM.nextInt(2);
        double direct = (d == 0) ? (Math.PI / 4) : (-5 * Math.PI / 4);
        int yaxis = RANDOM.nextInt(500) + 150;
        if (this.size == ALIENSHIP_SCALE[1])
        {
            AlienShip m = new AlienShip(-20, yaxis, 3.0, direct, size, controller);
            controller.addParticipant(m);
        }
        else
        {
            AlienShip n = new AlienShip(-20, yaxis, 5.0, direct, size, controller);
            controller.addParticipant(n);
        }
    }

    public void killShip ()
    {
        if (size == ALIENSHIP_SCALE[1])
        {
            AlienBullets b = new AlienBullets(this.getX(), this.getY(), RANDOM.nextDouble() * Math.PI * 2, controller);
            controller.addParticipant(b);
            new ParticipantCountdownTimer(b, "disappear", BULLET_DURATION);
        }
        else
        {
            if (controller.getShip() != null)
            {
                Ship ship = controller.getShip();
                double min = 0.0;
                double max = 0.0;
                if (ship.getX() >= this.getX())
                {
                    min = Math.PI / 2
                            - Math.atan2(Math.abs(ship.getX() - this.getX()), Math.abs(ship.getY() - this.getY()))
                            - Math.PI / 18;
                    max = Math.PI / 2
                            - Math.atan2(Math.abs(ship.getX() - this.getX()), Math.abs(ship.getY() - this.getY()))
                            + Math.PI / 18;
                }
                else
                {
                    min = Math.PI / 2
                            + Math.atan2(Math.abs(ship.getX() - this.getX()), Math.abs(ship.getY() - this.getY()))
                            - Math.PI / 18;
                    max = Math.PI / 2
                            + Math.atan2(Math.abs(ship.getX() - this.getX()), Math.abs(ship.getY() - this.getY()))
                            + Math.PI / 18;
                }
                double direct = min + (max - min) * RANDOM.nextDouble();
                AlienBullets b = new AlienBullets(this.getX(), this.getY(), direct, controller);
                controller.addParticipant(b);
                new ParticipantCountdownTimer(b, "disappear", BULLET_DURATION);
            }
        }
    }

    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof AlienShipDestroyer)
        {   
            Clip bangAlienShip = sound.createClip("/sounds/bangAlienShip.wav");
            bangAlienShip.start();
            Debris d1 = new Debris(this.getX(), this.getY(), "Ship", controller);
            Debris d2 = new Debris(this.getX(), this.getY(), "Ship", controller);
            Debris d3 = new Debris(this.getX(), this.getY(), "Ship", controller);
            controller.addParticipant(d1);
            controller.addParticipant(d2);
            controller.addParticipant(d3);
            new ParticipantCountdownTimer(d1, 1000);
            new ParticipantCountdownTimer(d2, 1000);
            new ParticipantCountdownTimer(d3, 1000);
            
            appearAgain();            
            Participant.expire(this);
            
        }

    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    @Override
    public void countdownComplete (Object payload)
    {
        if (payload.equals("appearing"))
        {
            setVelocity(this.speed, this.direction);
        }

        else if (payload.equals("moving"))
        {
            if (this.direction == -5 * Math.PI / 4)
            {
                int d = RANDOM.nextInt(2);
                if (d == 0)
                {
                    this.direction = -3 * Math.PI / 4;
                }
                else
                {
                    this.direction = -Math.PI;
                }
                setDirection(this.direction);
                if (size == ALIENSHIP_SCALE[1])
                {
                    new ParticipantCountdownTimer(this, "moving", 5000);
                }
                else
                {
                    new ParticipantCountdownTimer(this, "moving", 1000);
                }
                return;
            }

            if (this.direction == -3 * Math.PI / 4 || this.direction == -Math.PI)
            {
                this.direction = -5 * Math.PI / 4;
                setDirection(this.direction);
                if (size == ALIENSHIP_SCALE[1])
                {
                    new ParticipantCountdownTimer(this, "moving", 5000);
                }
                else
                {
                    new ParticipantCountdownTimer(this, "moving", 1000);
                }
                return;
            }
            if (this.direction == Math.PI / 4)
            {
                int d = RANDOM.nextInt(2);
                if (d == 0)
                {
                    this.direction = 7 * Math.PI / 4;
                }
                else
                {
                    this.direction = 0;
                }
                setDirection(this.direction);
                if (size == ALIENSHIP_SCALE[1])
                {
                    new ParticipantCountdownTimer(this, "moving", 5000);
                }
                else
                {
                    new ParticipantCountdownTimer(this, "moving", 1000);
                }
                return;
            }
            if (this.direction == 7 * Math.PI / 4 || this.direction == 0)
            {
                this.direction = Math.PI / 4;
                setDirection(this.direction);
                if (size == ALIENSHIP_SCALE[1])
                {
                    new ParticipantCountdownTimer(this, "moving", 5000);
                }
                else
                {
                    new ParticipantCountdownTimer(this, "moving", 1000);
                }
                return;
            }
        }

        else if (payload.equals("killing"))
        {
            this.killShip();
            new ParticipantCountdownTimer(this, "killing", RANDOM.nextInt(1000) + 500);

        }
    }
}
