package asteroids.destroyers;

/**
 * Used to mark Participants that destroy bullets.
 */
public interface BulletsDestroyer
{

}
