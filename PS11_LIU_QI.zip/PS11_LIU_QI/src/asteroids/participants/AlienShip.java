package asteroids.participants;

import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import asteroids.destroyers.ShipDestroyer;
import asteroids.game.*;
import sounds.Sound;
import static asteroids.game.Constants.*;

public class AlienShip extends Participant implements ShipDestroyer
{
    /** The outline of the ship */
    private Shape outline;

    /** Game controller */
    private Controller controller;

    private double speed;

    private Sound sound;

    private int counter;

    /**
     * Constructs an alien ship at the specified coordinates that is pointed in the given direction.
     */
    public AlienShip (int x, int y, double speed, double direction, Controller controller)
    {
        this.controller = controller;
        setPosition(x, y);
        setVelocity(speed, direction);
        sound = new Sound();
        counter = 1;

        Path2D.Double poly = new Path2D.Double();
        poly.moveTo(20, 0);
        poly.lineTo(-20, -10);
        poly.moveTo(20, 0);
        poly.lineTo(-20, 10);
        poly.lineTo(-4, 6);
        poly.lineTo(-4, -6);
        outline = poly;

        double size = ALIENSHIP_SCALE[1];
        poly.transform(AffineTransform.getScaleInstance(size, size));
        // Schedule an acceleration in five seconds
        new ParticipantCountdownTimer(this, 5000);
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getX();
    }

    /**
     * Returns the y-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getY();
    }

    @Override
    public void move()
    {   
        if(counter % 150 ==0 )
        {
            if(this.getDirection() == 5 * Math.PI/ 4)
            {
                this.setDirection(3 * Math.PI/4);
            }
            if(this.getDirection() == 3 * Math.PI/4)
            {
                this.setDirection(5 * Math.PI/ 4);
            }
            if(this.getDirection() == 7 * Math.PI /4)
            {
                this.setDirection(Math.PI /4);
            }
            if(this.getDirection() == Math.PI/4)
            {
                this.setDirection(7 * Math.PI /4);
            }
        }
        super.move();
    }

    public void killShip ()
    {

    }

    @Override
    public void collidedWith (Participant p)
    {
        // TODO Auto-generated method stub

    }

    @Override
    protected Shape getOutline ()
    {
        // TODO Auto-generated method stub
        return null;
    }
    
   

}
