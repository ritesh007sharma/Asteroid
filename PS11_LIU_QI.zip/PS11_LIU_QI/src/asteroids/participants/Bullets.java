package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import java.util.Random;
import asteroids.destroyers.AsteroidDestroyer;
import asteroids.destroyers.BulletsDestroyer;
import asteroids.destroyers.ShipDestroyer;
import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

public class Bullets extends Participant implements AsteroidDestroyer, ShipDestroyer
{
    /** The outline of the bullet */
    private Shape outline;

    /** The game controller */
    private Controller controller;

    /** The size of the bullet */
    private double size;

    public Bullets (double x, double y, double direction, Controller controller)
    {
        this.size = BULLET_SIZE;
        this.controller = controller;
        setPosition(x, y);
        setRotation(direction);
        setVelocity(BULLET_SPEED, direction);
        setDirection(direction);
        createBulletOutline(size);
    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    /**
     * Returns the x-coordinate of the point on the screen where the bullet's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(3, 0);
        transformPoint(point);
        return point.getX();
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(3, 0);
        transformPoint(point);
        return point.getY();
    }

    /**
     * Creates the outline of the bullet based on its size.
     */
    private void createBulletOutline (double size)
    {
        // This will contain the outline
        Path2D.Double poly = new Path2D.Double();

        poly.moveTo(1, 1);
        poly.lineTo(1, -1);
        poly.lineTo(-1, -1);
        poly.lineTo(-1, 1);
        poly.lineTo(1, 1);
        poly.closePath();

        // Scale to the desired size
        poly.transform(AffineTransform.getScaleInstance(size, size));

        // Save the outline
        outline = poly;
    }

    @Override
    public void collidedWith (Participant p)
    {   
        if (p instanceof ShipDestroyer)
        {
            Participant.expire(this);           
        }
        if (p instanceof Asteroid)
        {   
            controller.asteroidDestroyed();
            if (((Asteroid) p).getSize() == 2)
            {   
                controller.addParticipant(new Asteroid(((Asteroid) p).getVariety(), ((Asteroid) p).getSize() - 1,
                        p.getX(), p.getY(), RANDOM.nextInt(MAXIMUM_MEDIUM_ASTEROID_SPEED-2)+3, controller));
                controller.addParticipant(new Asteroid(((Asteroid) p).getVariety(), ((Asteroid) p).getSize() - 1,
                        p.getX(), p.getY(), RANDOM.nextInt(MAXIMUM_MEDIUM_ASTEROID_SPEED-2)+3, controller));
            }
            else if (((Asteroid) p).getSize() == 1)
            {   
                controller.addParticipant(new Asteroid(((Asteroid) p).getVariety(), ((Asteroid) p).getSize() - 1,
                        p.getX(), p.getY(), RANDOM.nextInt(MAXIMUM_SMALL_ASTEROID_SPEED-4) +5, controller));
                controller.addParticipant(new Asteroid(((Asteroid) p).getVariety(), ((Asteroid) p).getSize() - 1,
                        p.getX(), p.getY(), RANDOM.nextInt(MAXIMUM_SMALL_ASTEROID_SPEED-4) +5, controller));
            }
        }
        

    }

    @Override
    public void countdownComplete (Object payload)
    {       
         Participant.expire(this);
    }

}
