package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import java.util.Random;
import javax.sound.sampled.Clip;
import asteroids.destroyers.*;
import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;
import sounds.Sound;

/**
 * Represents ships
 */
public class Ship extends Participant implements AsteroidDestroyer
{
    /** The outline of the ship */
    private Shape outline;

    /** Game controller */
    private Controller controller;

    private double direction;

    private double speedX;

    private double speedY;

    private boolean isMoving;

    private boolean isFlaming;
    
    private Sound sound;

    /**
     * Constructs a ship at the specified coordinates that is pointed in the given direction.
     */
    public Ship (int x, int y, double direction, Controller controller)
    {
        this.controller = controller;
        this.direction = direction;
        setPosition(x, y);
        setRotation(this.direction);
        isMoving = false;
        isFlaming = false;
        createShipOutline2();
        sound = new Sound();

        // Schedule an acceleration in two seconds
        new ParticipantCountdownTimer(this, "move", 2000);
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getX();
    }

    /**
     * Returns the y-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getY();
    }

    @Override
    public Shape getOutline ()
    {
        return outline;
    }

    public void createShipOutline1 ()
    {
        if (!isFlaming)
        {
            Path2D.Double p1 = new Path2D.Double();
            p1.moveTo(20, 0);
            p1.lineTo(-20, -10);
            p1.moveTo(20, 0);
            p1.lineTo(-20, 10);
            p1.lineTo(-4, 6);
            p1.lineTo(-4, -6);
            outline = p1;

        }
        else
        {
            Path2D.Double p2 = new Path2D.Double();
            p2.moveTo(20, 0);
            p2.lineTo(-20, -10);
            p2.moveTo(20, 0);
            p2.lineTo(-20, 10);
            p2.lineTo(-4, 6);
            p2.lineTo(-4, -6);
            p2.lineTo(-18, 0);
            p2.lineTo(-4, 6);
            outline = p2;

        }

        new ParticipantCountdownTimer(this, "flamming", 50);
    }

    public void createShipOutline2 ()
    {
        Path2D.Double p3 = new Path2D.Double();
        p3.moveTo(20, 0);
        p3.lineTo(-20, -10);
        p3.moveTo(20, 0);
        p3.lineTo(-20, 10);
        p3.lineTo(-4, 6);
        p3.lineTo(-4, -6);
        outline = p3;

    }

    @Override
    public void setDirection (double direction)
    {
        this.direction = this.direction + direction;
        double d = normalize(this.direction);
        double speed = getSpeed();
        speedX = Math.cos(d) * speed;
        speedY = Math.sin(d) * speed;
    }

    @Override
    public double getDirection ()
    {
        return this.direction;
    }

    /**
     * Customizes the base move method by imposing friction
     */
    @Override
    public void move ()
    {
        applyFriction(SHIP_FRICTION);
        super.move();
    }

    /**
     * Turns right by Pi/16 radians
     */
    public void turnRight ()
    {
        rotate(Math.PI / 16);
        this.setDirection(Math.PI / 16);

    }

    /**
     * Turns left by Pi/16 radians
     */
    public void turnLeft ()
    {
        rotate(-Math.PI / 16);
        this.setDirection(-Math.PI / 16);

    }

    /**
     * Accelerates by SHIP_ACCELERATION
     */
    public void accelerate ()
    {
        createShipOutline1();
        Clip thrustClip = sound.createClip("/sounds/thrust.wav");
        thrustClip.start();
        accelerate(SHIP_ACCELERATION);

    }

    public void shoot ()
    {   
        Clip fireClip = sound.createClip("/sounds/fire.wav");
        fireClip.start();
        Bullets b = new Bullets(this.getXNose(), this.getYNose(), this.getDirection(), controller);
        controller.addParticipant(b);
        new ParticipantCountdownTimer(b, BULLET_DURATION);

    }

   // public void setMoving (boolean moving)
    //{
        //this.isMoving = moving;
    //}

    //public boolean getIsMoving ()
    //{
        //return this.isMoving;
    //}

    public void setFlame (boolean flame)
    {
        this.isFlaming = flame;
    }

    public boolean getFlame ()
    {
        return this.isFlaming;
    }
    

    /**
     * When a Ship collides with a ShipDestroyer, it expires
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof ShipDestroyer)
        {   
            Debris d1 = new Debris(this.getX(), this.getY(), "Ship", controller);
            Debris d2 = new Debris(this.getX(), this.getY(), "Ship", controller);
            Debris d3 = new Debris(this.getX(), this.getY(), "Ship", controller);
            controller.addParticipant(d1);
            controller.addParticipant(d2);
            controller.addParticipant(d3);
            new ParticipantCountdownTimer(d1, 1000);
            new ParticipantCountdownTimer(d2, 1000);
            new ParticipantCountdownTimer(d3, 1000);
            
            Clip bangShipClip = sound.createClip("/sounds/bangShip.wav");
            bangShipClip.start();
            
            // Expire the ship from the game
            Participant.expire(this);
            p.expire(p);

            // Tell the controller the ship was destroyed
            controller.shipDestroyed();
            controller.asteroidDestroyed();
            
           
        }
        if (p instanceof Asteroid)
        {
            if (((Asteroid) p).getSize() == 2)
            {
                Random r1 = new Random();
                controller.addParticipant(new Asteroid(((Asteroid) p).getVariety(), ((Asteroid) p).getSize() - 1,
                        p.getX(), p.getY(), r1.nextInt(MAXIMUM_MEDIUM_ASTEROID_SPEED - 2) + 3, controller));
                controller.addParticipant(new Asteroid(((Asteroid) p).getVariety(), ((Asteroid) p).getSize() - 1,
                        p.getX(), p.getY(), r1.nextInt(MAXIMUM_MEDIUM_ASTEROID_SPEED - 2) + 3, controller));
            }
            else if (((Asteroid) p).getSize() == 1)
            {
                Random r2 = new Random();
                controller.addParticipant(new Asteroid(((Asteroid) p).getVariety(), ((Asteroid) p).getSize() - 1,
                        p.getX(), p.getY(), r2.nextInt(MAXIMUM_SMALL_ASTEROID_SPEED - 4) + 5, controller));
                controller.addParticipant(new Asteroid(((Asteroid) p).getVariety(), ((Asteroid) p).getSize() - 1,
                        p.getX(), p.getY(), r2.nextInt(MAXIMUM_SMALL_ASTEROID_SPEED - 4) + 5, controller));
            }
        }

    }

    /**
     * This method is invoked when a ParticipantCountdownTimer completes its countdown.
     */
    @Override
    public void countdownComplete (Object payload)
    {
        // Give a burst of acceleration, then schedule another
        // burst for 200 msecs from now.
        if (payload.equals("move"))
        {
            accelerate();
            new ParticipantCountdownTimer(this, "move", 200);
        }
        else if (payload.equals("flamming"))
        {
            isFlaming = (isFlaming == false) ? true : false;
            createShipOutline1();
            getOutline();
        }

    }
}
