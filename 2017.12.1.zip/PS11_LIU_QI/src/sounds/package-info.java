/**
 * Sounds for the game
 * @author Joe Zachary
 */
package sounds;