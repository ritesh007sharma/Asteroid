package asteroids.destroyers;

/**
 * Used to mark Participants that destroy Ships.
 */
public interface ShipDestroyer
{
}
