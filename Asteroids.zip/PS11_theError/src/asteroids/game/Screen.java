package asteroids.game;

import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.participants.Ship;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.Iterator;
import javax.swing.JPanel;

/**
 * The area of the display in which the game takes place.
 */
@SuppressWarnings("serial")
public class Screen extends JPanel
{
    /** Legend that is displayed across the screen */
    private String legend;
    /** other things display across the screen */
    private String score;

    private int lives;

    private String level;

    /** Game controller */
    private Controller controller;

    private Font largeFont = new Font("SansSerif", 0, 100);

    private Font smallFont = new Font("SansSerif", 0, 25);

    private Ship shipMode;

    /**
     * Creates an empty screen
     */
    public Screen (Controller controller)
    {
        this.controller = controller;

        this.legend = "";

        this.score = "";

        this.level = "";

        this.setPreferredSize(new Dimension(Constants.SIZE, Constants.SIZE));

        this.setMinimumSize(new Dimension(Constants.SIZE, Constants.SIZE));

        this.setBackground(Color.black);

        this.setForeground(Color.white);

        this.setFocusable(true);

        this.shipMode = new Ship(0, 0, -Math.acos(0), null);
    }
    
    

    /**
     * Set the legend
     */
    public void setLegend (String legend)
    {
        this.legend = legend;
    }

    public void setScores (int n)
    {
        this.score = String.valueOf(n);
    }

    public void setLives (int n)
    {
        this.lives = n;
    }

    public void setLevel (int n)
    {
        this.level = String.valueOf(n);
    }

    /**
     * Paint the participants onto this panel
     */
    @Override
    public void paintComponent (Graphics graphics)
    {

        Graphics2D g = (Graphics2D) graphics;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        super.paintComponent(g);

        Iterator<Participant> iter = this.controller.getParticipants();

        while (iter.hasNext())
        {
            iter.next().draw(g);
        }

        this.setFont(this.largeFont);

        int size = g.getFontMetrics().stringWidth(this.legend);

        g.drawString(this.legend, (Constants.SIZE - size) / 2, Constants.SIZE / 2);

        g.setFont(this.smallFont);
        g.drawString(this.score, Constants.LABEL_HORIZONTAL_OFFSET, Constants.LABEL_HORIZONTAL_OFFSET);

        double center = Constants.LABEL_HORIZONTAL_OFFSET + g.getFontMetrics().stringWidth(this.score) / 2;

        g.drawString(this.level,
                Constants.SIZE - g.getFontMetrics().stringWidth(this.level) - Constants.LABEL_HORIZONTAL_OFFSET,
                Constants.LABEL_HORIZONTAL_OFFSET);

        double start = center - (double) (this.lives * Constants.SHIP_WIDTH / 2)
                - (double) ((this.lives - 1) * Constants.SHIP_SEPARATION / 10);
        int i = 0;
        while (i < this.lives)
        {
            this.shipMode.setPosition(start + Constants.SHIP_WIDTH / 2, 2 * Constants.SHIP_HEIGHT);
            this.shipMode.move();
            this.shipMode.draw(g);
            start = start + Constants.SHIP_WIDTH + Constants.SHIP_SEPARATION;
            i++;
        }
    }

}