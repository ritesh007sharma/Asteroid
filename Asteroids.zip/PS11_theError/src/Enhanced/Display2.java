package Enhanced;


import asteroids.game.Constants;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Defines the top-level appearance of an Asteroids game.
 */
@SuppressWarnings("serial")
public class Display2 extends JFrame
{
    /** The area where the action takes place */
    private Screen2 screen;
    private JLabel ScoreSoFar;

    private EnhancedController controller;

    /**
     * Lays out the game and creates the controller
     */
    public Display2 (EnhancedController controller)
    {
        // Title at the top
        this.setTitle(Constants.TITLE);
        // Default behavior on closing
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // The main playing area and the controller
        this.screen = new Screen2(controller);
        this.controller = controller;
        JPanel screenPanel = new JPanel();
        screenPanel.setLayout(new GridBagLayout());
        screenPanel.add(this.screen);

        JPanel controls = new JPanel();
        controls.setLayout(new GridLayout(1, 2));
        JPanel left = new JPanel();
        JPanel RightToLeft = new JPanel();

        controls.add(left);
        controls.add(RightToLeft);

        JButton startGame = new JButton(Constants.START_LABEL);
        left.add(startGame);

        ScoreSoFar = new JLabel();
        RightToLeft.add(ScoreSoFar);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(screenPanel, "Center");
        mainPanel.add(controls, "North");

        this.setContentPane(mainPanel);
        this.pack();

        refresh();

        startGame.addActionListener(controller);

        this.setLives(3);
        this.setLevel(1);
        this.setScores(0);

    }

    public void refresh ()
    {
        this.setLives(controller.getLives());
        this.setLevel(controller.getLevel());
        this.setScores(controller.getScores());
        this.setScoreSoFar(controller.getHighestScore());
        this.screen.repaint();
    }

    public void setScoreSoFar (int n)
    {
        this.ScoreSoFar.setText("HighestScore:" + n);
    }

    public void setLevel (int n)
    {

        this.screen.setLevel(n);

    }

    public void setLives (int n)
    {

        this.screen.setLives(n);
    }

    public void setScores (int n)
    {
        this.screen.setScores(n);
    }

    public void setLegend (String s)
    {
        this.screen.setLegend(s);
    }
}