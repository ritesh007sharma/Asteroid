package Enhanced;
import static asteroids.game.Constants.RANDOM;
import java.awt.Shape;
import java.awt.geom.Path2D;
import asteroids.game.Participant;


    public class Debris2 extends Participant
    {
        /** The outline of the bullet */
        private Shape outline;

        /**
         * The constructor of a debris with specific location and its participant
         */
        public Debris2 (double x, double y, String participant)
        {
            setPosition(x, y);
            setVelocity(2, RANDOM.nextDouble() * 2 * Math.PI);
            setRotation(2 * Math.PI * RANDOM.nextDouble());
            createOutline(participant);
        }

        @Override
        protected Shape getOutline ()
        {
            return outline;
        }

        protected void createOutline (String participant)
        {   
            // Create outline for Ship and AlienShip
            if (participant.equals("Ship"))
            {
                Path2D.Double poly = new Path2D.Double();
                poly.moveTo(7, 5);
                poly.lineTo(-7, -5);
                outline = poly;
            }
            
            // Create outline for Asteroid
            else if (participant.equals("Asteroid"))
            {
                Path2D.Double poly = new Path2D.Double();
                poly.moveTo(1, 1);
                poly.lineTo(1, -1);
                poly.lineTo(-1, -1);
                poly.lineTo(-1, 1);
                poly.lineTo(1, 1);
                outline = poly;
            }
        }

        @Override
        public void collidedWith (Participant p)
        {
            // TODO Auto-generated method stub

        }

        @Override
        public void countdownComplete (Object payload)
        {
            Participant.expire(this);
        }

    }


