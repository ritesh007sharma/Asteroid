/**
 * This package contains the high-level classes that coordinate
 * the appearance and operation of the game.
 */
package asteroids.game;