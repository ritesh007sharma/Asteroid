package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.*;
import javax.sound.sampled.Clip;
import asteroids.destroyers.*;
import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;
import sounds.Sound;

/**
 * Represents ships
 */
public class Ship extends Participant implements AsteroidDestroyer, AlienShipDestroyer
{
    /** The outline of the ship */
    private Shape outline;

    /** Game controller */
    private Controller controller;

    private double direction;

    private double speedX;

    private double speedY;

    private boolean isFlaming;

    private Sound sound;

    private boolean isShootingBoolean;

    private int counter;

    private Clip beat1;

    private Clip beat2;

    private Clip fireClip;

    private Clip thrustClip;


    /**
     * Constructs a ship at the specified coordinates that is pointed in the given direction.
     */
    public Ship (int x, int y, double direction, Controller controller)
    {
        this.controller = controller;
        this.direction = direction;
        this.speedX = 0;
        this.speedY = 0;
        setPosition(x, y);
        setRotation(this.direction);
        isFlaming = false;
        createShipOutline2();
        sound = new Sound();
        isShootingBoolean = false;

        this.counter = 0;
        beat2 = sound.createClip("/sounds/beat2.wav");
        beat1 = sound.createClip("/sounds/beat1.wav");
        fireClip = sound.createClip("/sounds/fire.wav");
        thrustClip = sound.createClip("/sounds/thrust.wav");

    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getX();
    }

    /**
     * Returns the y-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getY();
    }

    @Override
    public Shape getOutline ()
    {
        return outline;
    }

    public void createShipOutline1 ()
    {
        if (!isFlaming)
        {
            Path2D.Double p1 = new Path2D.Double();
            p1.moveTo(20, 0);
            p1.lineTo(-21, -12);
            p1.moveTo(20, 0);
            p1.lineTo(-21, 12);
            p1.lineTo(-14, 10);
            p1.lineTo(-14, -10);
            p1.closePath();
            outline = p1;

        }
        else
        {
            Path2D.Double p2 = new Path2D.Double();
            p2.moveTo(20, 0);
            p2.lineTo(-21, -12);
            p2.moveTo(20, 0);
            p2.lineTo(-21, 12);
            p2.lineTo(-14, 10);
            p2.lineTo(-14, -10);
            p2.lineTo(-20, 0);
            p2.lineTo(-14, 10);
            p2.closePath();
            outline = p2;

        }

        new ParticipantCountdownTimer(this, "flamming", 50);
    }

    public void createShipOutline2 ()
    {
        Path2D.Double p3 = new Path2D.Double();
        p3.moveTo(20, 0);
        p3.lineTo(-21, -12);
        p3.moveTo(20, 0);
        p3.lineTo(-21, 12);
        p3.lineTo(-14, 10);
        p3.lineTo(-14, -10);
        p3.closePath();
        outline = p3;

    }

    @Override
    public void setDirection (double direction)
    {
        this.direction = this.direction + direction;
        double d = normalize(this.direction);
        double speed = getSpeed();
        this.speedX = Math.cos(d) * speed;
        this.speedY = Math.sin(d) * speed;
    }

    @Override
    public double getDirection ()
    {
        return this.direction;
    }

    /**
     * Customizes the base move method by imposing friction
     * 
     * This method is run 30 times a second!!!
     */
    @Override
    public void move ()
    {
        counter++;

        if (counter <= 300)
        {
            if (counter % 30 == 0 && (counter / 30) % 2 == 0)
            {
                beat2.setMicrosecondPosition(0);
                beat2.start();
            }
            else if (counter % 30 == 0 && (counter / 30) % 2 == 1)
            {
                beat1.setMicrosecondPosition(0);
                beat1.start();
            }
        }
        else if (counter <= 600)
        {
            if (counter % 25 == 0 && (counter / 25) % 2 == 0)
            {
                beat2.setMicrosecondPosition(0);
                beat2.start();
            }
            else if (counter % 25 == 0 && (counter / 25) % 2 == 1)
            {
                beat1.setMicrosecondPosition(0);
                beat1.start();
            }
        }
        else if (counter <= 900)
        {
            if (counter % 20 == 0 && (counter / 20) % 2 == 0)
            {
                beat2.setMicrosecondPosition(0);
                beat2.start();
            }
            else if (counter % 20 == 0 && (counter / 20) % 2 == 1)
            {
                beat1.setMicrosecondPosition(0);
                beat1.start();
            }
        }
        else
        {
            if (counter % 15 == 0 && (counter / 15) % 2 == 0)
            {
                beat2.setMicrosecondPosition(0);
                beat2.start();
            }
            else if (counter % 15 == 0 && (counter / 15) % 2 == 1)
            {
                beat1.setMicrosecondPosition(0);
                beat1.start();
            }
        }

        applyFriction(SHIP_FRICTION);
        super.move();
    }

    /**
     * Turns right by Pi/16 radians
     */
    public void turnRight ()
    {
        rotate(Math.PI / 16);
        this.setDirection(Math.PI / 16);

    }

    /**
     * Turns left by Pi/16 radians
     */
    public void turnLeft ()
    {
        rotate(-Math.PI / 16);
        this.setDirection(-Math.PI / 16);

    }

    /**
     * Accelerates by SHIP_ACCELERATION
     */
    public void accelerate ()
    {
        createShipOutline1();
        thrustClip.setMicrosecondPosition(0);
        thrustClip.start();
        accelerate(SHIP_ACCELERATION);

    }

    public void shoot ()
    {

        if (this.isShootingBoolean)
        {
            fireClip.setMicrosecondPosition(0);
            fireClip.start();
            Bullets b = new Bullets(this.getXNose(), this.getYNose(), this.getDirection());

            controller.addParticipant(b);
            new ParticipantCountdownTimer(b, BULLET_DURATION);
            
        }

    }

    public void setIsShootingBoolean (boolean s)
    {
        this.isShootingBoolean = s;
    }

    public boolean getIsShootingBoolean ()
    {
        return this.isShootingBoolean;
    }

    public void setFlame (boolean flame)
    {
        this.isFlaming = flame;
    }

    public boolean getFlame ()
    {
        return this.isFlaming;
    }


    /**
     * When a Ship collides with a ShipDestroyer, it expires
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof ShipDestroyer)
        {
            Debris d1 = new Debris(this.getX(), this.getY(), "Ship");
            Debris d2 = new Debris(this.getX(), this.getY(), "Ship");
            Debris d3 = new Debris(this.getX(), this.getY(), "Ship");
            controller.addParticipant(d1);
            controller.addParticipant(d2);
            controller.addParticipant(d3);
            new ParticipantCountdownTimer(d1, 1500);
            new ParticipantCountdownTimer(d2, 1500);
            new ParticipantCountdownTimer(d3, 1500);

            // Expire the ship from the game
            Participant.expire(this);

            // Tell the controller the ship was destroyed
            controller.shipDestroyed();
            controller.asteroidDestroyed();

        }

    }

    /**
     * This method is invoked when a ParticipantCountdownTimer completes its countdown.
     */
    @Override
    public void countdownComplete (Object payload)
    {

        if (payload.equals("flamming"))
        {
            if (controller.getAccelerateBoolean() == false)
            {
                createShipOutline2();
                isFlaming = false;
                return;
            }
            isFlaming = (isFlaming == false) ? true : false;
            createShipOutline1();
        }
    }
}
