package asteroids.participants;

import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import javax.sound.sampled.Clip;
import asteroids.destroyers.*;
import asteroids.game.*;
import sounds.Sound;
import static asteroids.game.Constants.*;

public class AlienShip extends Participant implements ShipDestroyer
{
    /** The outline of the ship */
    private Shape outline;

    /** Game controller */
    private Controller controller;

    /** The speed of the AlienShip */
    private double speed;

    /** The initial direction of the AlienShip */
    private double direction;

    /** The sound object that contains the sound when AlienShip shows up */
    private Sound sound;

    /** The size of the AlienShip */
    private double size;

    /** An int for measure the time */
    private int count;

    /** the sound when AlienShip shows up */
    private Clip saucer;

    /**
     * Constructs an alien ship at the specified coordinates that is pointed in the given direction.
     */
    public AlienShip (int x, int y, double speed, double direction, double size, Controller controller)
    {
        this.controller = controller;
        setPosition(x, y);
        this.size = size;
        this.speed = speed;
        this.direction = direction;
        sound = new Sound();
        this.count = 0;
        this.saucer = (this.size == ALIENSHIP_SCALE[0]) ? (sound.createClip("/sounds/saucerSmall.wav"))
                : (sound.createClip("/sounds/saucerBig.wav"));

        Path2D.Double poly = new Path2D.Double();
        outline = poly;

        poly.transform(AffineTransform.getScaleInstance(size, size));

        // After five seconds of new level, the AlienShip shows up
        new ParticipantCountdownTimer(this, "appearing", 5000);

        // Every five seconds the AlienShip changes its direction
        new ParticipantCountdownTimer(this, "ChangingDirection", 5000);

        // After six seconds the AlienShip starts to shoot the Ship
        new ParticipantCountdownTimer(this, "killing", 6000);
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(0, 0);
        transformPoint(point);
        return point.getX();

    }

    /**
     * Returns the y-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(0, 0);
        transformPoint(point);
        return point.getY();
    }

    @Override
    public void move ()
    {
        // When the AlienShip is out of the screen and still alive, it disappears
        super.move();
        if (!this.isExpired())
        {
            if (this.direction < 0 && this.getX() >= 0 && this.getX() < 4)
            {
                Participant.expire(this);

                // Add new ALienSHip on screen
                appearAgain();
            }
            else if (this.direction >= 0 && this.getX() > SIZE - 4 && this.getX() <= SIZE)
            {
                Participant.expire(this);

                appearAgain();
            }
        }

        // Using count to measure the time to play the sound
        count++;
        if (count > 150 && count < 240 && count % 3 == 1)
        {
            saucer.setMicrosecondPosition(0);
            saucer.start();
        }

    }

    /**
     * Helper method to add AlienShip
     */
    public void appearAgain ()
    {
        int d = RANDOM.nextInt(2);
        double direct = (d == 0) ? (Math.PI / 4) : (-5 * Math.PI / 4);
        int yaxis = RANDOM.nextInt(500) + 150;
        if (this.size == ALIENSHIP_SCALE[1])
        {
            AlienShip m = new AlienShip(-20, yaxis, 3.0, direct, size, controller);
            controller.addParticipant(m);
        }
        else
        {
            AlienShip n = new AlienShip(-20, yaxis, 5.0, direct, size, controller);
            controller.addParticipant(n);
        }
    }

    /** Shoot ALienBullets */
    public void killShip ()
    {   
        if (size == ALIENSHIP_SCALE[1])
        {
            AlienBullets b = new AlienBullets(this.getX(), this.getY(), RANDOM.nextDouble() * Math.PI * 2);
            controller.addParticipant(b);
            new ParticipantCountdownTimer(b, "disappear", BULLET_DURATION);
        }
        else
        {   
            if (controller.getShip() != null)
            {   
                // Set the direction of small AlienShip shooting AlienBullets
                Ship ship = controller.getShip();
                double min = 0.0;
                double max = 0.0;
                double angle = Math.atan2(Math.abs(ship.getX() - this.getX()), Math.abs(ship.getY() - this.getY()));
                if (ship.getX() >= this.getX())
                {
                    if (ship.getY() >= this.getY())
                    {
                        min = Math.PI / 2 - angle - Math.PI / 18;
                        max = Math.PI / 2 - angle + Math.PI / 18;
                    }
                    else
                    {
                        min = -(Math.PI / 2 - angle - Math.PI / 18);
                        max = -(Math.PI / 2 - angle + Math.PI / 18);
                    }
                }
                else
                {
                    if (ship.getY() >= this.getY())
                    {
                        min = Math.PI / 2 + angle - Math.PI / 18;
                        max = Math.PI / 2 + angle + Math.PI / 18;
                    }
                    else
                    {
                        min = -(Math.PI / 2 + angle - Math.PI / 18);
                        max = -(Math.PI / 2 + angle + Math.PI / 18);
                    }
                }
                double direct = min + (max - min) * RANDOM.nextDouble();
                AlienBullets b = new AlienBullets(this.getX(), this.getY(), direct);
                controller.addParticipant(b);
                // After eight seconds the AlienBullet disappears
                new ParticipantCountdownTimer(b, "disappear", BULLET_DURATION);
            }
        }
    }
    
    /**
     * When AlienShip collides with AlienShipDestroyer, it expires
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof AlienShipDestroyer)
        {
            Clip bangAlienShip = sound.createClip("/sounds/bangAlienShip.wav");
            bangAlienShip.start();
            Debris d1 = new Debris(this.getX(), this.getY(), "Ship");
            Debris d2 = new Debris(this.getX(), this.getY(), "Ship");
            Debris d3 = new Debris(this.getX(), this.getY(), "Ship");
            controller.addParticipant(d1);
            controller.addParticipant(d2);
            controller.addParticipant(d3);
            new ParticipantCountdownTimer(d1, 1000);
            new ParticipantCountdownTimer(d2, 1000);
            new ParticipantCountdownTimer(d3, 1000);
            
            controller.addScores(200);
            appearAgain();
            Participant.expire(this);

        }

    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    @Override
    public void countdownComplete (Object payload)
    {
        if (payload.equals("appearing"))
        {
            Path2D.Double poly = new Path2D.Double();
            poly.moveTo(20, 0);
            poly.lineTo(9, 9);
            poly.lineTo(-9, 9);
            poly.lineTo(-20, 0);
            poly.lineTo(20, 0);
            poly.lineTo(-20, 0);
            poly.lineTo(-9, -9);
            poly.lineTo(9, -9);
            poly.lineTo(-9, -9);
            poly.lineTo(-5, -17);
            poly.lineTo(5, -17);
            poly.lineTo(9, -9);
            poly.closePath();
            outline = poly;
            poly.transform(AffineTransform.getScaleInstance(size, size));

            setVelocity(this.speed, this.direction);
        }

        else if (payload.equals("ChangingDirection"))
        {
            if (this.direction == -5 * Math.PI / 4)
            {
                int d = RANDOM.nextInt(2);
                if (d == 0)
                {
                    this.direction = -3 * Math.PI / 4;
                }
                else
                {
                    this.direction = -Math.PI;
                }
                setDirection(this.direction);
                if (size == ALIENSHIP_SCALE[1])
                {
                    new ParticipantCountdownTimer(this, "ChangingDirection", 2000);
                }
                else
                {
                    new ParticipantCountdownTimer(this, "ChangingDirection", 1000);
                }
                return;
            }

            if (this.direction == -3 * Math.PI / 4 || this.direction == -Math.PI)
            {
                this.direction = -5 * Math.PI / 4;
                setDirection(this.direction);
                if (size == ALIENSHIP_SCALE[1])
                {
                    new ParticipantCountdownTimer(this, "ChangingDirection", 2000);
                }
                else
                {
                    new ParticipantCountdownTimer(this, "ChangingDirection", 1000);
                }
                return;
            }
            if (this.direction == Math.PI / 4)
            {
                int d = RANDOM.nextInt(2);
                if (d == 0)
                {
                    this.direction = 7 * Math.PI / 4;
                }
                else
                {
                    this.direction = 0;
                }
                setDirection(this.direction);
                if (size == ALIENSHIP_SCALE[1])
                {
                    new ParticipantCountdownTimer(this, "ChangingDirection", 2000);
                }
                else
                {
                    new ParticipantCountdownTimer(this, "ChangingDirection", 1000);
                }
                return;
            }
            if (this.direction == 7 * Math.PI / 4 || this.direction == 0)
            {
                this.direction = Math.PI / 4;
                setDirection(this.direction);
                if (size == ALIENSHIP_SCALE[1])
                {
                    new ParticipantCountdownTimer(this, "ChangingDirection", 2000);
                }
                else
                {
                    new ParticipantCountdownTimer(this, "ChangingDirection", 1000);
                }
                return;
            }
        }

        else if (payload.equals("killing"))
        {
            this.killShip();
            new ParticipantCountdownTimer(this, "killing", RANDOM.nextInt(500) + 500);
        }
    }
}
