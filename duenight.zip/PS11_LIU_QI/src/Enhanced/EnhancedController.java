package Enhanced;

import static asteroids.game.Constants.*;
import java.awt.event.*;
import java.util.Iterator;
import javax.swing.*;
import asteroids.game.Participant;
import asteroids.game.ParticipantState;

/**
 * Controls a game of Asteroids.
 */
public class EnhancedController implements KeyListener, ActionListener
{
    /** The state of all the Participants */
    private ParticipantState pstate;

    /** The ship (if one is active) or null (otherwise) */
    private Ship2 shipA;

    private Ship2 shipB;

    /** When this timer goes off, it is time to refresh the animation */
    private Timer refreshTimer;

    private boolean turnRight1;

    private boolean turnLeft1;

    private boolean turnRight2;

    private boolean turnLeft2;

    private boolean accelerating1;

    private boolean accelerating2;

    private int level;

    private int totalScores;

    private int lives;

    /**
     * The time at which a transition to a new stage of the game should be made. A transition is scheduled a few seconds
     * in the future to give the user time to see what has happened before doing something like going to a new level or
     * resetting the current level.
     */
    private long transitionTime;

    /** The game display */
    private Display2 display;

    /**
     * Constructs a controller to coordinate the game and screen
     */
    public EnhancedController ()
    {

        // Initialize the ParticipantState
        pstate = new ParticipantState();

        // Set up the refresh timer.
        refreshTimer = new Timer(FRAME_INTERVAL, this);

        // Clear the transitionTime
        transitionTime = Long.MAX_VALUE;

        // Record the display object
        display = new Display2(this);

        // Lives of the ship has
        lives = 5;

        // Bring up the splash screen and start the refresh timer
        splashScreen();
        display.setVisible(true);
        refreshTimer.start();
        turnRight1 = false;
        turnLeft1 = false;
        accelerating1 = false;
        turnRight2 = false;
        turnLeft2 = false;
        accelerating2 = false;
        this.level = 1;
        this.totalScores = 0;
    }

    /**
     * Returns the ship, or null if there isn't one
     */
    public Ship2 getShipA ()
    {
        return shipA;
    }

    public Ship2 getShipB ()
    {
        return shipB;
    }

    /**
     * Return the lives remaining
     */
    public int getLives ()
    {
        return this.lives;
    }

    public void setScores ()
    {
        this.totalScores = 0;
    }

    public int getScores ()
    {
        return totalScores;
    }

    public void addScores (int scores)
    {
        this.totalScores = this.totalScores + scores;
    }

    public void setLevel ()
    {
        this.level = 1;
    }

    public int getLevel ()
    {
        return this.level;
    }

    /**
     * Configures the game screen to display the splash screen
     */
    private void splashScreen ()
    {
        // Clear the screen, reset the level, and display the legend
        clear();
        display.setLegend("Asteroids");

        // Place four asteroids near the corners of the screen.
        placeAsteroids2();
    }

    /**
     * The game is over. Displays a message to that effect.
     */
    private void finalScreen ()
    {
        display.setLegend(GAME_OVER);
        display.removeKeyListener(this);
    }

    private void placeShipA ()
    {
        // Place a new ship
        Participant.expire(shipA);
        shipA = new Ship2(2 * SIZE / 3, SIZE / 2, -Math.PI / 2, this);
        addParticipant(shipA);
    }

    private void placeShipB ()
    {
        // Place a new ship
        Participant.expire(shipB);
        shipB = new Ship2(SIZE / 3, SIZE / 2, -Math.PI / 2, this);
        addParticipant(shipB);
    }

    /**
     * Places an asteroid near one corner of the screen. Gives it a random velocity and rotation.
     */
    private void placeAsteroids2 ()
    {
        int i = 0;

        addParticipant(new Asteroid2(2, EDGE_OFFSET, EDGE_OFFSET, 3, this));
        addParticipant(new Asteroid2(2, EDGE_OFFSET, -EDGE_OFFSET, 3, this));
        addParticipant(new Asteroid2(2, -EDGE_OFFSET, EDGE_OFFSET, 3, this));
        addParticipant(new Asteroid2(2, -EDGE_OFFSET, -EDGE_OFFSET, 3, this));
        while (i < this.level - 1)
        {
            addParticipant(new Asteroid2(0, RANDOM.nextDouble(), EDGE_OFFSET, 3, this));
            i++;
        }
    }

    private void placeAlienShip2 ()
    {
        int d = RANDOM.nextInt(2);
        double direction = 0.0;
        int xaxis = 0;
        if (d == 0)
        {
            direction = -5 * Math.PI / 4;
            xaxis = SIZE + 15;
        }
        else
        {
            direction = Math.PI / 4;
            xaxis = -14;
        }
        if (level == 2)
        {
            addParticipant(new AlienShip2(xaxis, 150, 3.0, direction, ALIENSHIP_SCALE[1], this));
        }
        else if (level > 2)
        {
            addParticipant(new AlienShip2(xaxis, 150, 5.0, direction, ALIENSHIP_SCALE[0], this));
        }
    }

    /**
     * Clears the screen so that nothing is displayed
     */
    private void clear ()
    {
        pstate.clear();
        display.setLegend("");
        shipA = null;
        shipB = null;
    }

    /**
     * Sets things up and begins a new game.
     */
    private void initialScreen ()
    {
        // Clear the screen
        clear();

        this.level = 1;

        this.lives = 5;

        setScores();

        // Plac asteroids
        placeAsteroids2();

        // Place the ship
        placeShipA();

        placeShipB();

        // Start listening to events (but don't listen twice)
        display.removeKeyListener(this);
        display.addKeyListener(this);

        // Give focus to the game screen
        display.requestFocusInWindow();
    }

    /**
     * Adds a new Participant
     */
    public void addParticipant (Participant p)
    {
        pstate.addParticipant(p);
    }

    /**
     * The ship has been destroyed
     */
    public void shipDestroyed ()
    {

        if (shipA.isCollided())
        {
            shipA = null;
            lives--;

        }

        if (shipB.isCollided())
        {
            shipB = null;
            lives--;
        }

        scheduleTransition(500);

    }

    /**
     * An asteroid has been destroyed
     */
    public void asteroidDestroyed ()
    {
        // If all the asteroids are gone, schedule a transition
        if (pstate.countAsteroids2() == 0)
        {
            this.level = this.level + 1;
            lives ++;
            if (this.level >= 2)
            {
                pstate.removeAlienShip2();
            }
            scheduleTransition(END_DELAY);

        }
    }

    /**
     * Schedules a transition m msecs in the future
     */
    private void scheduleTransition (int m)
    {
        transitionTime = System.currentTimeMillis() + m;
    }

    /**
     * This method will be invoked because of button presses and timer events.
     */
    @Override
    public void actionPerformed (ActionEvent e)
    {
        if (turnRight1 && shipA != null)
        {
            shipA.turnRight();
        }
        if (turnLeft1 && shipA != null)
        {
            shipA.turnLeft();
        }
        if (accelerating1 && shipA != null)
        {
            shipA.accelerate();
        }
        if (turnRight2 && shipB != null)
        {
            shipB.turnRight();
        }
        if (turnLeft2 && shipB != null)
        {
            shipB.turnLeft();
        }
        if (accelerating2 && shipB != null)
        {
            shipB.accelerate();
        }
        if (e.getSource() instanceof JButton)
        {
            initialScreen();
        }

        // Time to refresh the screen and deal with keyboard input
        else if (e.getSource() == refreshTimer)
        {

            // It may be time to make a game transition
            performTransition();

            // Move the participants to their new locations
            pstate.moveParticipants();

            // Refresh screen
            display.refresh();
        }
    }

    /**
     * Returns an iterator over the active participants
     */
    public Iterator<Participant> getParticipants ()
    {
        return pstate.getParticipants();
    }

    /**
     * If the transition time has been reached, transition to a new state
     */
    private void performTransition ()
    {
        // Do something only if the time has been reached
        if (transitionTime <= System.currentTimeMillis())
        {
            // Clear the transition time
            transitionTime = Long.MAX_VALUE;

            // If there are no lives left, the game is over. Show the final
            // screen.
            if (lives == 0)
            {
                finalScreen();
            }
            else
            {
                if (this.getShipA() == null)
                {
                    placeShipA();
                }
                if (this.getShipB() == null)
                {
                    placeShipB();
                }
            }

            if (pstate.countAsteroids2() == 0)
            {
                this.placeAsteroids2();
            }
            if (this.level >= 2 && pstate.countAlienShip2() == 0)
            {
                placeAlienShip2();
            }
        }

    }

    /**
     * If a key of interest is pressed, record that it is down.
     */
    @Override
    public void keyPressed (KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT && shipA != null)
        {
            turnRight1 = true;
        }

        if (e.getKeyCode() == KeyEvent.VK_LEFT && shipA != null)
        {
            turnLeft1 = true;
        }

        if (e.getKeyCode() == KeyEvent.VK_UP && shipA != null)
        {
            // ship.setAccelerateBoolean(true);
            accelerating1 = true;
            shipA.setFlame(true);
        }

        if ((e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_SPACE) && shipA != null)
        {

            shipA.setIsShootingBoolean(true);
            shipA.shoot();

        }
        if (e.getKeyCode() == KeyEvent.VK_D && shipB != null)
        {
            turnRight2 = true;
        }

        if (e.getKeyCode() == KeyEvent.VK_A && shipB != null)
        {
            turnLeft2 = true;
        }

        if (e.getKeyCode() == KeyEvent.VK_W && shipB != null)
        {
            // ship.setAccelerateBoolean(true);
            accelerating2 = true;
            shipB.setFlame(true);
        }

        if (e.getKeyCode() == KeyEvent.VK_S && shipB != null)
        {

            shipB.setIsShootingBoolean(true);
            shipB.shoot();

        }

    }

    public boolean getAccelerateBoolean1 ()
    {
        return this.accelerating1;
    }

    public boolean getAccelerateBoolean2 ()
    {
        return this.accelerating2;
    }

    /**
     * These events are ignored.
     */
    @Override
    public void keyTyped (KeyEvent e)
    {
    }

    @Override
    public void keyReleased (KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT && shipA != null)
        {
            turnRight1 = false;
        }

        if (e.getKeyCode() == KeyEvent.VK_LEFT && shipA != null)
        {
            turnLeft1 = false;
        }

        if (e.getKeyCode() == KeyEvent.VK_UP && shipA != null)
        {
            // ship.setAccelerateBoolean(false);
            accelerating1 = false;
            shipA.createShipOutline2();
        }

        if ((e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_SPACE) && shipA != null)
        {
            shipA.setIsShootingBoolean(false);

        }
        if (e.getKeyCode() == KeyEvent.VK_D && shipB != null)
        {
            turnRight2 = false;
        }

        if (e.getKeyCode() == KeyEvent.VK_A && shipB != null)
        {
            turnLeft2 = false;
        }

        if (e.getKeyCode() == KeyEvent.VK_W && shipB != null)
        {
            // ship.setAccelerateBoolean(false);
            accelerating2 = false;
            shipB.createShipOutline2();
        }

        if (e.getKeyCode() == KeyEvent.VK_S && shipB != null)
        {
            shipB.setIsShootingBoolean(false);

        }

    }
}
