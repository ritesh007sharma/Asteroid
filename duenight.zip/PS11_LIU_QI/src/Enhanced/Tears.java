package Enhanced;

import java.awt.Shape;
import java.awt.geom.Path2D;
import asteroids.game.Participant;

public class Tears extends Participant
{
    /** The outline of the tears */
    private Shape outline;

    /** The size of the bullet */
    private double size;

    public Tears (double x, double y, double direction)
    {
        this.size = 1;
        setPosition(x, y);
        setRotation(direction);
        setVelocity(10, direction);
        setDirection(direction);
        createOutline(size);
    }

    public void createOutline (double size)
    {
        Path2D.Double poly = new Path2D.Double();

        poly.moveTo(0, -10);
        poly.quadTo(-4, -3, 0, 0);
        poly.quadTo(4, -3, 0, -10);
        poly.closePath();
        
        outline = poly;
    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    @Override
    public void collidedWith (Participant p)
    {
    }
    
    @Override
    public void countdownComplete (Object payload)
    {
        if(payload.equals("cry"))
        {
            Participant.expire(this);
        }
    }
}
