package Enhanced;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import javax.sound.sampled.Clip;
import Enhanced.EnhancedController;
import asteroids.destroyers.AsteroidDestroyer;
import asteroids.destroyers.BulletsDestroyer;
import asteroids.destroyers.ShipDestroyer;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;
import sounds.Sound;

/**
 * Represents asteroids
 */
public class Asteroid2 extends Participant implements ShipDestroyer, BulletsDestroyer
{
    /** The size of the asteroid (0 = small, 1 = medium, 2 = large) */
    private int size;

    /** The outline of the asteroid */
    private Shape outline;

    /** The game controller */
    private EnhancedController controller;

    private Sound sound;

    private Clip Cry;

    private boolean isCrying;

    /**
     * Throws an IllegalArgumentException if size or variety is out of range.
     * 
     * Creates an asteroid of the specified variety (0 through 3) and size (0 = small, 1 = medium, 2 = large) and
     * positions it at the provided coordinates with a random rotation. Its velocity has the given speed but is in a
     * random direction.
     */
    public Asteroid2 (int size, double x, double y, int speed, EnhancedController controller)
    {
        // Make sure size and variety are valid
        if (size < 0 || size > 2)
        {
            throw new IllegalArgumentException("Invalid asteroid size: " + size);
        }

        // Create the asteroid
        this.controller = controller;
        this.size = size;
        this.isCrying = false;
        setPosition(x, y);
        setVelocity(speed, RANDOM.nextDouble() * 2 * Math.PI);
        createAsteroidOutline1(size);
        
        sound = new Sound();
        Cry = sound.createClip("/sounds/cry.wav");

        new ParticipantCountdownTimer(this, "face2", 1000);
    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    /**
     * Creates the outline of the asteroid based on its variety and size.
     */
    private void createAsteroidOutline1 (int size)
    {
        // This will contain the outline
        Path2D poly = new Path2D.Double();

        poly.append(new Ellipse2D.Double(-30, -30, 60, 60), true);
        poly.moveTo(-9, 0);
        poly.quadTo(-14, -10, -19, -10);
        poly.quadTo(-16, 0, -9, 0);
        poly.moveTo(9, 0);
        poly.quadTo(14, -10, 19, -10);
        poly.quadTo(16, 0, 9, 0);
        poly.moveTo(-9, 20);
        poly.lineTo(0, 9);
        poly.lineTo(9, 20);
        poly.lineTo(0, 27);
        poly.lineTo(-9, 20);
        poly.closePath();

        // Scale to the desired size
        double scale = ASTEROID_SCALE[size];
        poly.transform(AffineTransform.getScaleInstance(scale, scale));

        // Save the outline
        outline = poly;
    }

    private void createAsteroidOutline2 (int size)
    {
        // This will contain the outline
        Path2D poly = new Path2D.Double();

        poly.append(new Ellipse2D.Double(-30, -30, 60, 60), true);
        poly.moveTo(-9, 0);
        poly.quadTo(-14, -10, -19, -10);
        poly.quadTo(-16, 0, -9, 0);
        poly.moveTo(9, 0);
        poly.quadTo(14, -10, 19, -10);
        poly.quadTo(16, 0, 9, 0);
        poly.moveTo(-9, 20);
        poly.lineTo(9, 20);
        poly.closePath();

        // Scale to the desired size
        double scale = ASTEROID_SCALE[size];
        poly.transform(AffineTransform.getScaleInstance(scale, scale));

        // Save the outline
        outline = poly;
    }

    private void createAsteroidOutline3 (int size)
    {
        // This will contain the outline
        Path2D poly = new Path2D.Double();

        poly.append(new Ellipse2D.Double(-30, -30, 60, 60), true);
        poly.moveTo(-9, 0);
        poly.lineTo(-19, -10);
        poly.moveTo(9, 0);
        poly.lineTo(19, -10);
        poly.moveTo(-9, 20);
        poly.lineTo(0, 9);
        poly.lineTo(9, 20);
        poly.closePath();

        // Scale to the desired size
        double scale = ASTEROID_SCALE[size];
        poly.transform(AffineTransform.getScaleInstance(scale, scale));

        // Save the outline
        outline = poly;
    }

    public double getLeftEyeX ()
    {
        Point2D.Double point = new Point2D.Double(-16, 0);
        transformPoint(point);
        return point.getX();
    }

    public double getLeftEyeY ()
    {
        Point2D.Double point = new Point2D.Double(-16, 0);
        transformPoint(point);
        return point.getY();
    }

    public double getRightEyeX ()
    {
        Point2D.Double point = new Point2D.Double(16, 0);
        transformPoint(point);
        return point.getX();
    }

    public double getRightEyeY ()
    {
        Point2D.Double point = new Point2D.Double(16, 0);
        transformPoint(point);
        return point.getY();
    }

    private void cry ()
    {
        if (isCrying)
        {
            createAsteroidOutline3(size);
            Tears t1 = new Tears(getLeftEyeX(), getLeftEyeY(), Math.PI / 2);
            Tears t2 = new Tears(getRightEyeX(), getRightEyeY(), Math.PI / 2);
            controller.addParticipant(t1);
            controller.addParticipant(t2);

            new ParticipantCountdownTimer(t1, "cry", 1500);
            new ParticipantCountdownTimer(t2, "cry", 1500);
            new ParticipantCountdownTimer(this, "cryAgain", 500);
        }
    }

    /**
     * Returns the size of the asteroid
     */
    public int getSize ()
    {
        return size;
    }

    /**
     * When an Asteroid collides with an AsteroidDestroyer, it expires.
     */
    // @Override
    public void collidedWith (Participant p)
    {
        
        if (p instanceof AsteroidDestroyer)
        {   
            Cry.setMicrosecondPosition(0);
            Cry.start();
            isCrying = true;
            cry();
            setSpeed(0);
        }

    }

    @Override
    public void countdownComplete (Object payload)
    {
        if (payload.equals("face2"))
        {
            createAsteroidOutline2(size);
            new ParticipantCountdownTimer(this, "face1", 1000);
        }
        else if (payload.equals("face1"))
        {
            createAsteroidOutline1(size);
            new ParticipantCountdownTimer(this, "face2", 1000);
        }

        else if (payload.equals("cryAgain"))
        {
            if (isCrying)
            {
                cry();
                new ParticipantCountdownTimer(this, "keepCrying", 500);
            }
        }
        else if (payload.equals("keepCrying"))
        {
            if (isCrying)
            {
                cry();
                isCrying = false;
                Participant.expire(this);
                controller.asteroidDestroyed();
            }
            if (this.getSize() == 2)
            {
                controller.addParticipant(new Asteroid2(this.getSize() - 1, this.getX(), this.getY(),
                        RANDOM.nextInt(MAXIMUM_MEDIUM_ASTEROID_SPEED - 2) + 3, controller));
                controller.addParticipant(new Asteroid2(this.getSize() - 1, this.getX(), this.getY(),
                        RANDOM.nextInt(MAXIMUM_MEDIUM_ASTEROID_SPEED - 2) + 3, controller));
                controller.addScores(20);
            }
            else if (this.getSize() == 1)
            {
                controller.addParticipant(new Asteroid2(this.getSize() - 1, this.getX(), this.getY(),
                        RANDOM.nextInt(MAXIMUM_SMALL_ASTEROID_SPEED - 4) + 5, controller));
                controller.addParticipant(new Asteroid2(this.getSize() - 1, this.getX(), this.getY(),
                        RANDOM.nextInt(MAXIMUM_SMALL_ASTEROID_SPEED - 4) + 5, controller));
                controller.addScores(50);
            }
            else
            {
                controller.addScores(100);
            }
           
            
        }
    }

}
