package Enhanced;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import javax.sound.sampled.Clip;
import Enhanced.EnhancedController;
import asteroids.destroyers.*;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;
import asteroids.participants.Bullets;
import asteroids.participants.Debris;
import sounds.Sound;

/**
 * Represents ships
 */
public class Ship2 extends Participant implements AsteroidDestroyer, AlienShipDestroyer
{
    
        /** The outline of the ship */
        private Shape outline;

        /** Game controller */
        private EnhancedController controller;

        private double direction;

        private double speedX;

        private double speedY;

        private boolean isFlaming;

        private Sound sound;

        private boolean isShootingBoolean;

        private int counter;

        private Clip beat1;

        private Clip beat2;
        
        private boolean isCollided;
        
        

        /**
         * Constructs a ship at the specified coordinates that is pointed in the given direction.
         */
        public Ship2 (int x, int y, double direction, EnhancedController controller)
        {
            this.controller = controller;
            this.direction = direction;
            this.speedX = 0;
            this.speedY = 0;
            setPosition(x, y);
            setRotation(this.direction);
            isFlaming = false;
            createShipOutline2();
            sound = new Sound();
            isShootingBoolean = false;
            isCollided = false;
            this.isCollided = false;

            this.counter = 0;
            beat2 = sound.createClip("/sounds/beat2.wav");
            beat1 = sound.createClip("/sounds/beat1.wav");

        }

        /**
         * Returns the x-coordinate of the point on the screen where the ship's nose is located.
         */
        public double getXNose ()
        {
            Point2D.Double point = new Point2D.Double(40, 0);
            transformPoint(point);
            return point.getX();
        }

        /**
         * Returns the y-coordinate of the point on the screen where the ship's nose is located.
         */
        public double getYNose ()
        {
            Point2D.Double point = new Point2D.Double(40, 0);
            transformPoint(point);
            return point.getY();
        }

        @Override
        public Shape getOutline ()
        {
            return outline;
        }


    public void createShipOutline1 ()
    {
        if (!isFlaming)
        {
            Path2D.Double p = new Path2D.Double();
            p.moveTo(20, -14);
            p.lineTo(20, 14);
            p.lineTo(40, 0);
            p.lineTo(20, -14);
            p.lineTo(-25, -14);
            p.lineTo(-25, 14);
            p.lineTo(20, 14);
            p.lineTo(-25, -14);
            p.moveTo(-25, 14);
            p.lineTo(20, -14);
            p.closePath();
            outline = p;
        }
        else
        {
            Path2D.Double p = new Path2D.Double();
            p.moveTo(20, -14);
            p.lineTo(20, 14);
            p.lineTo(40, 0);
            p.lineTo(20, -14);
            p.lineTo(-25, -14);
            p.lineTo(-25, 14);
            p.lineTo(20, 14);
            p.lineTo(-25, -14);
            p.moveTo(-25, 14);
            p.lineTo(20, -14);
            p.moveTo(-25, -14);
            p.lineTo(-55, -19);
            p.lineTo(-48, -10);
            p.lineTo(-50, -7);
            p.lineTo(-48, -3);
            p.lineTo(-50, 0);
            p.lineTo(-48, 10);
            p.lineTo(-55, 19);
            p.lineTo(-25, 14);
            p.closePath();
            outline = p;
        }

        new ParticipantCountdownTimer(this, "flamming", 20);

    }

    public void createShipOutline2 ()
    {
        Path2D.Double p = new Path2D.Double();
        p.moveTo(20, -14);
        p.lineTo(20, 14);
        p.lineTo(40, 0);
        p.lineTo(20, -14);
        p.lineTo(-25, -14);
        p.lineTo(-25, 14);
        p.lineTo(20, 14);
        p.lineTo(-25, -14);
        p.moveTo(-25, 14);
        p.lineTo(20, -14);
        p.closePath();
        outline = p;

    }

    @Override
    public void setDirection (double direction)
    {
        this.direction = this.direction + direction;
        double d = normalize(this.direction);
        double speed = getSpeed();
        this.speedX = Math.cos(d) * speed;
        this.speedY = Math.sin(d) * speed;
    }

    @Override
    public double getDirection ()
    {
        return this.direction;
    }

    /**
     * Customizes the base move method by imposing friction
     * 
     * This method is run 30 times a second!!!
     */
    @Override
    public void move ()
    {
        counter++;

        if (counter <= 300)
        {
            if (counter % 30 == 0 && (counter / 30) % 2 == 0)
            {
                beat2.setMicrosecondPosition(0);
                beat2.start();
            }
            else if (counter % 30 == 0 && (counter / 30) % 2 == 1)
            {
                beat1.setMicrosecondPosition(0);
                beat1.start();
            }
        }
        else if (counter <= 600)
        {
            if (counter % 25 == 0 && (counter / 25) % 2 == 0)
            {
                beat2.setMicrosecondPosition(0);
                beat2.start();
            }
            else if (counter % 25 == 0 && (counter / 25) % 2 == 1)
            {
                beat1.setMicrosecondPosition(0);
                beat1.start();
            }
        }
        else if (counter <= 900)
        {
            if (counter % 20 == 0 && (counter / 20) % 2 == 0)
            {
                beat2.setMicrosecondPosition(0);
                beat2.start();
            }
            else if (counter % 20 == 0 && (counter / 20) % 2 == 1)
            {
                beat1.setMicrosecondPosition(0);
                beat1.start();
            }
        }
        else
        {
            if (counter % 15 == 0 && (counter / 15) % 2 == 0)
            {
                beat2.setMicrosecondPosition(0);
                beat2.start();
            }
            else if (counter % 15 == 0 && (counter / 15) % 2 == 1)
            {
                beat1.setMicrosecondPosition(0);
                beat1.start();
            }
        }

        applyFriction(SHIP_FRICTION);
        super.move();
    }

    /**
     * Turns right by Pi/16 radians
     */
    public void turnRight ()
    {
        rotate(Math.PI / 16);
        this.setDirection(Math.PI / 16);

    }

    /**
     * Turns left by Pi/16 radians
     */
    public void turnLeft ()
    {
        rotate(-Math.PI / 16);
        this.setDirection(-Math.PI / 16);

    }

    /**
     * Accelerates by SHIP_ACCELERATION
     */
    public void accelerate ()
    {
        createShipOutline1();
        Clip thrustClip = sound.createClip("/sounds/thrust.wav");
        thrustClip.start();
        accelerate(SHIP_ACCELERATION);

    }

    public void shoot ()
    {
        if (this.isShootingBoolean)
        {
            Clip fireClip = sound.createClip("/sounds/fire.wav");
            fireClip.start();
            Bullets b = new Bullets(this.getXNose(), this.getYNose(), this.getDirection());
            controller.addParticipant(b);
            new ParticipantCountdownTimer(b, BULLET_DURATION);

        }

    }

    public void setIsShootingBoolean (boolean s)
    {
        this.isShootingBoolean = s;
    }

    public boolean getIsShootingBoolean ()
    {
        return this.isShootingBoolean;
    }

    public void setFlame (boolean flame)
    {
        this.isFlaming = flame;
    }

    public boolean getFlame ()
    {
        return this.isFlaming;
    }
    
    public boolean isCollided()
    {
        return this.isCollided;
    }

    /**
     * When a Ship collides with a ShipDestroyer, it expires
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof ShipDestroyer)
        {   
            isCollided =  true;
            Debris d1 = new Debris(this.getX(), this.getY(), "Ship");
            Debris d2 = new Debris(this.getX(), this.getY(), "Ship");
            Debris d3 = new Debris(this.getX(), this.getY(), "Ship");
            controller.addParticipant(d1);
            controller.addParticipant(d2);
            controller.addParticipant(d3);
            new ParticipantCountdownTimer(d1, 1500);
            new ParticipantCountdownTimer(d2, 1500);
            new ParticipantCountdownTimer(d3, 1500);

            // Expire the ship from the game
            Participant.expire(this);

            // Tell the controller the ship was destroyed
            controller.shipDestroyed();
            controller.asteroidDestroyed();
            this.isCollided = true;

        }

    }

    /**
     * This method is invoked when a ParticipantCountdownTimer completes its countdown.
     */
    @Override
    public void countdownComplete (Object payload)
    {

        if (payload.equals("flamming"))
        {
            if (controller.getAccelerateBoolean1() == false)
            {
                createShipOutline2();
                isFlaming = false;
            }
            if (controller.getAccelerateBoolean2() == false)
            {
                createShipOutline2();
                isFlaming = false;
            }
            else
            {
            isFlaming = (isFlaming == false) ? true : false;
            createShipOutline1();
            }
        }
    }
}
