package Enhanced;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import javax.sound.sampled.Clip;
import asteroids.destroyers.AlienShipDestroyer;
import asteroids.destroyers.ShipDestroyer;
import asteroids.game.Participant;
import sounds.Sound;

public class AlienBullets2 extends Participant implements ShipDestroyer
{
    /** The outline of the bullet */
    private Shape outline;

    /** The size of the bullet */
    private double size;

    /** The sound when AlienBullets collide with other participants */
    private Sound sound;

    /** bangShip sound */
    private Clip bangShip;

    /**
     * The constructor of AlienBullets given the specific coordinates and direction
     */
    public AlienBullets2 (double x, double y, double direction)
    {
        this.size = BULLET_SIZE;
        setPosition(x, y);
        setRotation(direction);
        setVelocity(BULLET_SPEED, direction);
        setDirection(direction);
        createBulletOutline(size);
        this.sound = new Sound();
        this.bangShip = sound.createClip("/sounds/bangShip.wav");
    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    /**
     * Returns the x-coordinate of the point on the screen where the bullet's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(3, 0);
        transformPoint(point);
        return point.getX();
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(3, 0);
        transformPoint(point);
        return point.getY();
    }

    /**
     * Creates the outline of the bullet based on its size.
     */
    private void createBulletOutline (double size)
    {
        // This will contain the outline
        Path2D.Double poly = new Path2D.Double();

        poly.moveTo(1, 1);
        poly.lineTo(1, -1);
        poly.lineTo(-1, -1);
        poly.lineTo(-1, 1);
        poly.lineTo(1, 1);
        poly.closePath();

        // Scale to the desired size
        poly.transform(AffineTransform.getScaleInstance(size, size));

        // Save the outline
        outline = poly;
    }

    /**
     * When an AlienBullet collides with other participants, it expires
     */
    @Override
    public void collidedWith (Participant p)
    {
        Participant.expire(this);
        if (p instanceof AlienShipDestroyer)
        {
            bangShip.setMicrosecondPosition(0);
            bangShip.start();
            Participant.expire(p);
        }
    }

    @Override
    public void countdownComplete (Object payload)
    {
        if (payload.equals("disappear"))
        {
            Participant.expire(this);
        }
    }

}
